## Py Is (pyis)

**pyis** is a library to check values in your python projects.

Here is how to install **pyis**

- Way number 1 : **Using pip**

```
pip3 install pyis
```

- Way number 2 : **Clone and install**

```
git clone https://github.com/BlackIQ/pyis && cd pyis
pip3 install -e .
```
